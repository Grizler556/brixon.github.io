if there is nothing if you load the map, put the map.xml file into C:\brixonmaps\
the folder might not exist so you will have to make it manually, once you will make it. you can put mas in there

IMPORTANT!!!
THE MAP WILL ONLY LOAD IF THE NAME OF THE MAP IS MAP.XML MAKE SURE TO PUT IT IN THE RIGHT
DIRECTORY